<?php

define('PELICULA', 1);
define('SERIE', 2);
define('JUEGO', 3);
define('LIBRO', 4);

define('ADMINISTRADOR', 1);
define('USUARIO', 3);
define('MODERADOR', 2);
define('VISITANTE', 4);

define('TABLA_TUSUARIO', 1);
define('TABLA_PLATAFORMA', 2);
define('TABLA_SUGE', 3);
define('TABLA_TOBRA', 4);

define('ACCION_CREAR', 1);
define('ACCION_ACTUALIZAR', 2);
define('ACCION_ELIMINAR', 3);


?>